
XDS100v2 EPK
Updated April 28, 2010

PURPOSE

To provide XDS100v2 reference design and additional information to enable 3rd parties to build the XDS100v2 hardware.

CONTENTS

/CPLD folder

contains CPLD JED and source files

/design and /lib folders

KICAD SOURCES
./xds100v2.pro		KICAD PROJECT FILE
./xds100v2.sch		TOP SCHEMATIC FILE
./ftdi2232h.sch		FTDI USB CHIP SCHEMATIC SHEET
./jtag.sch			JTAG CONNECTOR SCHEMATIC SHEET
../lib/xds100v2.lib		SCHEMATIC LIBRARY
../lib/xds100v2_pcblib.mod	MODULE (Footprint) LIBRARY
./xds100v2_pcblib.brd	SOURCE FILE FOR PCB MODULE FOOTPRINTS
./xds100v2.brd		PCB FILE

KICAD OUTPUTS
xds100v2.net		NETLIST  

GERBER FILES
xds100v2-Silks_Cmp.pho	Top Silkscreen
xds100v2-Mask_Cmp.pho	Top SolderMask
xds100v2-Component.pho	Top Copper
xds100v2-Inner_L1.pho	Inner Layer 1 Copper (Positive)
xds100v2-Inner_L2.pho	Inner Layer 2 Copper (Positive)
xds100v2-Copper.pho	Bottom Copper
xds100v2-Mask_Cop.pho	Bottom SolderMask
xds100v2-Silks_Cop.pho	Bottom Silkscreen
xds100v2-Drawings.pho	Board Outline, Mechanical Dimensions

xds100v2-SoldP_Cmp.pho	Top Solder Paste
xds100v2-SoldP_Cop.pho	Bottom Solder Paste

ASSEMBLY FILES
XDS100v2_BOM.xls		Bill of Materials (Excel 2003)
xds100v2-Component.pos	X,Y,Rot Position File for Component Placement
	
/MProg folder

contains MProg script file

/Schematic folder

contains XDS100v2 schematic in .pdf format


KNOWN BUG FOR EVM DESIGNERS

The CPLD programming pins were moved to Port BCBUS 4,5,6,7 to make room for the B port to be used as UART.

However, in the UART mode these pins are mostly used as status.  it appears there isn't a way to turn this behavior off, so if we continue using these pins as a recommendation - then we'll have CPLD TCK, TDI toggling based on UART activity.  TMS is connected to an input pin so it could conceiveably change state, and something might get scanned into the CPLD that affects it's functionality

RECOMMENDED FIX

BCBUS 1, 2, 5, and 6 are the only free pins on BCBUS when
the FTDI chip B port is in UART mode.

We should change the recommendation for CPLD in circuit programming to use:
 
BCBUS1 -> CPLD TCK
BCBUS2 -> CPLD TDI
BCBUS5 -> CPLD TDO
BCBUS6 -> CPLD TMS




